package org.cap.java8.demo;

import java.util.function.BiConsumer;

public class BiConsumerDemo {

	public static void main(String[] args) {
		
		BiConsumer<String, Integer> biConsumer=
				(str,num)->{
					int len=str.length();
					if(num==len)
						System.out.println("Length is same.");
				};
		
				biConsumer.accept("capgemini", 19);
	}

}
