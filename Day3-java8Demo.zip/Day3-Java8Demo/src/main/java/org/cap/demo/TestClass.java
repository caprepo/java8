package org.cap.demo;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.function.Predicate;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

public class TestClass {

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		
		
		ObjectMapper mapper=new ObjectMapper();
		List<Employee> employees=mapper.readValue(new File("C:\\vidavid\\Training\\2020\\Java8_29_jun_to_3_jul\\clsdemo\\Day3-Java8Demo\\src\\main\\java\\org\\cap\\demo\\employe.json"), 
				new TypeReference<List<Employee>>() {});
				
		
		Predicate<Employee> eyePredicate=
				(employee) -> employee.getEyeColor().equalsIgnoreCase("blue") ||
				 employee.getEyeColor().equalsIgnoreCase("brown") ||
				employee.getEyeColor().equalsIgnoreCase("black") ;
		
			
				
		employees.parallelStream()
			.filter(eyePredicate)
			.map((emp) -> {
				return emp.getName().getFirst().toUpperCase() + "   " +
						emp.getName().getLast().toUpperCase();
			})
			.sorted()
			.forEach(System.out::println);
		
			/*.forEach((emp) -> {
				System.out.println(emp.getName().getFirst()+" " 
						+emp.getName().getLast() + "-->" + 
						emp.getEyeColor());
			});
	
		
				
	*/			
		//System.out.println(employees);
		
		
	}

}
