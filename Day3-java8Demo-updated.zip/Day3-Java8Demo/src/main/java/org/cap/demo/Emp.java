package org.cap.demo;

public class Emp {

	private String first;
	private String last;
	
	
	
	
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getLast() {
		return last;
	}
	public void setLast(String last) {
		this.last = last;
	}
	@Override
	public String toString() {
		return "Emp [first=" + first + ", last=" + last + "]";
	}
	
	
	
}
