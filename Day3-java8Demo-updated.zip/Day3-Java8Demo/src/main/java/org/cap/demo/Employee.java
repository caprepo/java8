package org.cap.demo;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

public class Employee {

	private String _id;
    private int index;
    @JsonProperty
    private boolean isActive;
    private String guid;
    private String balance;
    private String picture;
    private int age;
    private String eyeColor;
    private String company;
    private String email;
    private String phone;
    private String address;
    private String about;
    private String registered;
    private String latitude;
    private String longitude;
    private String greeting;
    private String favoriteFruit;
    private List<String> tags;
    private List<String> range;
    private List<String> friends;
    //@JsonProperty
    private Emp name;
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getEyeColor() {
		return eyeColor;
	}
	public void setEyeColor(String eyeColor) {
		this.eyeColor = eyeColor;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	public String getRegistered() {
		return registered;
	}
	public void setRegistered(String registered) {
		this.registered = registered;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getGreeting() {
		return greeting;
	}
	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}
	public String getFavoriteFruit() {
		return favoriteFruit;
	}
	public void setFavoriteFruit(String favoriteFruit) {
		this.favoriteFruit = favoriteFruit;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	public List<String> getRange() {
		return range;
	}
	public void setRange(List<String> range) {
		this.range = range;
	}
	public List<String> getFriends() {
		return friends;
	}
	public void setFriends(List<String> friends) {
		this.friends = friends;
	}
	public Emp getName() {
		return name;
	}
	public void setName(Emp name) {
		this.name = name;
	}
	
	
	@Override
	public String toString() {
		return "Employee [_id=" + _id + ", index=" + index + ", isActive=" + isActive + ", guid=" + guid + ", balance="
				+ balance + ", picture=" + picture + ", age=" + age + ", eyeColor=" + eyeColor + ", company=" + company
				+ ", email=" + email + ", phone=" + phone + ", address=" + address + ", about=" + about
				+ ", registered=" + registered + ", latitude=" + latitude + ", longitude=" + longitude + ", greeting="
				+ greeting + ", favoriteFruit=" + favoriteFruit + ", tags=" + tags + ", range=" + range + ", friends="
				+ friends + ", name=" + name + "]";
	}
    
    
    
    
}
