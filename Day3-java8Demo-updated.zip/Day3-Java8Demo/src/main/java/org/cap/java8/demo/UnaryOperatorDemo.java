package org.cap.java8.demo;

import java.util.function.BinaryOperator;
import java.util.function.UnaryOperator;

public class UnaryOperatorDemo {

	public static void main(String[] args) {
		
		UnaryOperator<Integer> operator=(n1)-> n1;
		BinaryOperator<Integer> add=(n1,n2) -> n1+n2;
		BinaryOperator<Double> adddouble=(n1,n2) -> n1+n2;
		BinaryOperator<Integer> sub=(n1,n2) -> n1-n2;
		BinaryOperator<Integer> mul=(n1,n2) -> n1*n2;
		
		
		System.out.println(add.apply(234, 56));
		System.out.println(adddouble.apply(23.45, 56.12));
		System.out.println(sub.apply(234, 56));
		System.out.println(mul.apply(234, 56));
		
	}

}
