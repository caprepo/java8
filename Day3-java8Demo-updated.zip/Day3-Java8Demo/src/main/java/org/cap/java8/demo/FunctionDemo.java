package org.cap.java8.demo;

import java.util.function.Function;

public class FunctionDemo {

	public static void main(String[] args) {
		Function<String, String> fn= (str) -> str.toUpperCase();
		
		System.out.println(fn.apply("capgemini"));
	}

}
