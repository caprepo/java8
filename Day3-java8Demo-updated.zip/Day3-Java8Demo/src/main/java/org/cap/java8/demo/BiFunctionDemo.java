package org.cap.java8.demo;

import java.util.function.BiFunction;

public class BiFunctionDemo {

	public static void main(String[] args) {
	
		BiFunction<String, Integer,Boolean> fn=
				(str,num) -> {
					if(str.length()>=8) {
						if(num%2==0)
							return true;
					}
					return false;
				};
				
				boolean ans= fn.apply("capgemini", 20);
		System.out.println("Answer:" + ans);
	}

}
