package org.cap.java8.demo;

import java.util.stream.IntStream;

public class IntStreamDemo {

	public static void main(String[] args) {
		IntStream intStream=IntStream.of(12);
	}

}
