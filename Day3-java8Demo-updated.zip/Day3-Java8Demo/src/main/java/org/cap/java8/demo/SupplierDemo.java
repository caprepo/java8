package org.cap.java8.demo;

import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) {
		
		Supplier<String> supplier=() -> "Good evening!";
		
		System.out.println(supplier.get());
		
	}

}
