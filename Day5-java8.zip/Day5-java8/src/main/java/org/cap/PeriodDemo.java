package org.cap;

import java.time.Clock;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;

public class PeriodDemo {

	public static void main(String[] args) {
		Period period= Period.ofDays(100);
	Temporal temp=period.addTo(LocalDate.now());
	System.out.println(temp);
	
	Clock c=Clock.systemUTC();
	System.out.println(c.instant());
	
	Duration d=Duration.between(LocalTime.NOON,LocalTime.MAX);
	//LocalTime.NOON --> 12.00 PM
	//LocalTime.Max --> 24.00 PM
	System.out.println(d);
	System.out.println(d.get(ChronoUnit.SECONDS));
	
	Duration duration=Duration.between(LocalTime.of(12, 23), LocalTime.of(19, 22));
	System.out.println(duration);
	System.out.println(duration.getSeconds());
		
	}

}
