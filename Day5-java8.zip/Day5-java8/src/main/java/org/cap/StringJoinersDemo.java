package org.cap;

import java.util.StringJoiner;

public class StringJoinersDemo {

	public static void main(String[] args) {
		
		//StringJoiner joiner=new StringJoiner(",");
		StringJoiner joiner=new StringJoiner(",","(",")");
		
		joiner.add("tom");
		joiner.add("jack");
		joiner.add("thomson");
		joiner.add("annie");
		
		String str=joiner.toString();
		
		System.out.println(joiner);
		System.out.println(str);
		
	}

}
