package org.cap;

import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ZoneDateTimeDemo {

	public static void main(String[] args) {
		
		LocalDateTime dateTime=LocalDateTime.of(2020, 03, 13, 19, 15,26);
		ZoneId india=ZoneId.of("Asia/Kolkata");
		
		ZonedDateTime dateTime2=ZonedDateTime.of(dateTime,india);
		System.out.println(dateTime2);
		
		ZoneId tokyo=ZoneId.of("Asia/Tokyo");
		
		ZonedDateTime dateTime3=ZonedDateTime.of(dateTime,tokyo);
		System.out.println(dateTime3);
		
		ZonedDateTime zone=ZonedDateTime.now();
		System.out.println(zone);
		ZonedDateTime newdt= zone.plus(Period.ofDays(121));
		System.out.println(newdt);
	}

}
