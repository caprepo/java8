package org.cap;

import java.util.Optional;

public class OptionalDemo {

	public static void main(String[] args) {
		
		//Optional<Integer> num1=null;
		Optional<Integer> num1=Optional.empty();
		Optional<Integer> num2=Optional.of(null);
		
		System.out.println(num1.isPresent());
		System.out.println(num2.isPresent());
		
		
		  int value1=num1.orElse(new Integer(0)); 
		//int value1=num1.get();
		  int value2=num2.get();
		  
		  System.out.println(value1+value2);
		 
		
		
	}

}
