package org.cap;

import java.util.Arrays;

public class ParallelSortDemo {

	public static void main(String[] args) {
		
		int[] myarr= {23,5,-2,4,90,11,3,45,2,6,66};
		for(int num:myarr)
			System.out.print(num + " ");
		System.out.println();
		System.out.println("===========================");
		System.out.println();
		
		/*
		 * Arrays.parallelSort(myarr); for(int num:myarr) System.out.print(num + " ");
		 * System.out.println(); System.out.println("===========================");
		 * System.out.println();
		 */
		
		Arrays.parallelSort(myarr,3,7);
		for(int num:myarr)
			System.out.print(num + " ");
		System.out.println();
	}

}
