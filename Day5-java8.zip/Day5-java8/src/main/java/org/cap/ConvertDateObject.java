package org.cap;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class ConvertDateObject {

	public static void main(String[] args) {
		convertLocalDateTodate();
		
	}
	
	public static void convertLocalDateTodate() {
		LocalDate date=LocalDate.now();
		Instant instant= date.atStartOfDay(ZoneId.of("Asia/Calcutta")).toInstant();
		Date date2= Date.from(instant);
		System.out.println(date2);
	}
	
	public static void convertDateToLocalDate() {
		Date date=new Date();
		System.out.println(date);
		
		Instant instant=date.toInstant();
		System.out.println(instant);
		
		LocalDateTime dateTime= instant.atZone(ZoneId.of("Asia/Calcutta")).toLocalDateTime();
		System.out.println(dateTime);
		
	}

}
