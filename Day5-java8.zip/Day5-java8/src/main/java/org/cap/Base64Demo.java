package org.cap;

import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

public class Base64Demo {

	public static void main(String[] args) {
		
		String str="capgemini pvt ltd";
		Encoder  encoder= Base64.getEncoder();
		byte[] encoded=encoder.encode(str.getBytes());
		String ecryptedStr=new String(encoded);
		System.out.println(ecryptedStr);
		
		Decoder decoder= Base64.getDecoder();
		byte[] decoded=decoder.decode(ecryptedStr.getBytes());
		System.out.println(new String(decoded));
		
	}

}
