package org.cap;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Set;

public class LocalDateDemo {

	public static void main(String[] args) {
		LocalDate date=LocalDate.now();
		
		System.out.println(date);
		System.out.println(date.plusDays(1));
		System.out.println(date.plusMonths(1));
		System.out.println(date.plus(200, ChronoUnit.DAYS));
		
		
		LocalTime time=LocalTime.now();
		System.out.println(time);
		System.out.println(time.minus(10, ChronoUnit.HOURS));
		
		
		Set<String> zones=ZoneId.getAvailableZoneIds();
		for(String zone:zones)
			System.out.println(zone);
		
		LocalTime india= LocalTime.now(ZoneId.of("Asia/Kolkata"));
		LocalTime tokyo= LocalTime.now(ZoneId.of("Asia/Tokyo"));
		
		
		
		System.out.println(india);
		System.out.println(tokyo);
		
		LocalTime time2=LocalTime.of(22, 10, 34);
		System.out.println(time2);
		
		
		LocalDateTime dateTime=LocalDateTime.now();
		System.out.println(dateTime);
		
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yy HH:mm:ss");
		String mytime=dateTime.format(formatter);
		System.out.println(mytime);
		
		//private constructor immubale feature
		//LocalDate mydate=new LocalDate();
	}

}
