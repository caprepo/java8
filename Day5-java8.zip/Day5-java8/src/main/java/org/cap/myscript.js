var greet=function(){
	print("Hello! Good Evening!");
};

greet();