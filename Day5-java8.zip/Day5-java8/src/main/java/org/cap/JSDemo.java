package org.cap;

import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class JSDemo {

	public static void main(String[] args) throws ScriptException, FileNotFoundException {
		ScriptEngine ee=new ScriptEngineManager().getEngineByName("Nashorn");
		//ee.eval("print('Hello');");
		ee.eval(new FileReader("C:\\vidavid\\Training\\2020\\Java8_29_jun_to_3_jul\\clsdemo\\Day5-java8\\src\\main\\resources\\myscript.js"));
		
	}

}
