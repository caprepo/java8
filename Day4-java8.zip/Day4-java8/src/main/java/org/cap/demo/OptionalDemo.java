package org.cap.demo;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class OptionalDemo {

	public static void main(String[] args) {
		List<Integer> lst=Arrays.asList(1,2,3,4,4,56,7);
		Optional<Integer> sum= lst.parallelStream()
			.reduce((a,b) -> a+b);
		
		System.out.println(sum.ofNullable(null));
		
	}

}
