package org.cap.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class TestFlatMap {

	public static void main(String[] args) {
	
		Employee employee=new Employee(1001,"Tom","Jack");
		employee.getProjects().add("SCB - S2B project");
		employee.getProjects().add("SCB - EBS Project");
		
		Employee employee1=new Employee(1234,"Jack","Thomson");
		employee1.getProjects().add("SCB - S2B project");
		employee1.getProjects().add("CITI - Corebanking");
		
		Employee employee2=new Employee(3224,"Tim","Lee");
		employee2.getProjects().add("SCB - DigitalBanking");
		employee2.getProjects().add("CITI - Corebanking");
		
		
		List<Employee> employees=new ArrayList<Employee>();
		employees.add(employee2);
		employees.add(employee1);
		employees.add(employee);
		
		
		Set<String> projects= employees.stream()
			.flatMap((emp) -> emp.getProjects().stream())
			.collect(Collectors.toSet());
			//.distinct()
			//.forEach(System.out::println);
		
		System.out.println(projects);
	}

}
