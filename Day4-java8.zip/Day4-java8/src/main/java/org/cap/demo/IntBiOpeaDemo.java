package org.cap.demo;

import java.util.function.IntBinaryOperator;

public class IntBiOpeaDemo {
	
	public static void main(String[] args) {
		IntBinaryOperator operator=(n1,n2) -> n1+n2;
		System.out.println(operator.applyAsInt(12, 34));
	}

}
