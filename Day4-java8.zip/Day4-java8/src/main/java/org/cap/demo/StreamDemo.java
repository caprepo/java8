package org.cap.demo;

import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;

public class StreamDemo {

	public static void main(String[] args) {

		
		IntStream stream= IntStream.range(1, 51);
		stream.forEach(System.out::println);
		
		IntStream stream2= IntStream.of(12,56,67,90,11,9,10,2,4);
		//stream2.forEach(System.out::println);
		
			//OptionalInt sum= stream2.reduce((n1,n2) -> n1+n2);
			//stream2.close();
		//	int sum=stream2.reduce(0, (n1,n2)->n1+n2);
		//int sum=stream2.reduce(1, (n1,n2)->n1*n2);
		//int avg=stream2.reduce(0, (n1,n2)->(n1+n2/2));
	//OptionalInt max=stream2.reduce(Integer::max);
		//stream2.close();
		OptionalInt min=stream2.reduce(Integer::min);
	//	stream2.close();
			//System.out.println("Sum =" + sum);
			//System.out.println("Max =" + max);
			System.out.println("Min =" + min);
		
		
		DoubleStream doubleStream=DoubleStream.of(12.3,45.6,67.89,77.6,23.45);
		doubleStream.forEach(System.out::println);
		
		
	}

}
