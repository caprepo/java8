package org.cap.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMapDemo {

	public static void main(String[] args) {
		
		List<String> fruits=Arrays.asList("apple","orange","graps");
		List<String> names=Arrays.asList("tom","jack","kamal","harry");
		List<String> nums=Arrays.asList("1","3","4","5","7","9");
		
		List<List<String>> lst=new ArrayList<List<String>>();
		lst.add(fruits);
		lst.add(nums);
		lst.add(names);
		
		for(List<String> mylst:lst) {
			for(String str:mylst)
				System.out.println(str);
		}
		
		System.out.println("=======================================");
		List<String> strings= lst.stream()
			.flatMap((lst1)-> lst1.stream())
			.collect(Collectors.toList());
			//.forEach(System.out::println);
		
		System.out.println(lst);
		System.out.println(strings);
	}

}
