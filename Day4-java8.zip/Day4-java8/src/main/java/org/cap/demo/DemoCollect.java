package org.cap.demo;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class DemoCollect {

	public static void main(String[] args) {
		List<String> list= Arrays.asList("aaaa","bbbb","cccc","2321","ddddd","2132132"
				,"vvvvvvvvv","v","ssss");
		
		Predicate<String> predicate=(str) -> str.length()>=4;
		
		List<String>  anslst= list.parallelStream()
			.filter(predicate)
			.map((str) -> str.toUpperCase())
			.collect(Collectors.toList());
			//.forEach(System.out::println);
		
		System.out.println(list);
		System.out.println(anslst);
		
	}

}
