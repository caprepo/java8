package org.cap.demo;

import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;

public class StringjoinerDemo {

	public static void main(String[] args) {
		
		StringJoiner joiner=new StringJoiner(",");
		StringJoiner joiner1=new StringJoiner(",","(",")");
		
		
		
		List<String> list= Arrays.asList("one","two","three");
		
		//joiner.add(list.stream());
		
		//String joined=String.join("-", list);
		String joined=String.join("-", list);
		System.out.println(joined);
	}

}
